# Changelog

## 1.2026.513-10 — 2026-05-13

- Refined the Dictation History toolbar with clearer actions for replay, copy, delete, and re-transcribe.
- Improved the dictation island error state with a clearer message and easier recovery.
- Made re-transcribing past dictations more reliable.
- Polished Simplified Chinese copy across dictation, history, and settings for consistent terminology.

## 1.2026.513-9 — 2026-05-13

- Added Dictation History to review, replay, copy, delete, and re-transcribe past dictations, including failed or timed-out sessions.
- Added Dictation History settings for saving audio and automatic cleanup.
- Improved long dictations so trailing speech is less likely to be cut off while finishing.
- Refined the dictation island with a clearer error state, a cleaner live waveform, and a smaller animated processing state.
- The Context Dictionary editor now grows as you add longer content.

## 1.2026.513-8 — 2026-05-13

- Fixed realtime dictation finalization so the last words stay intact when the provider sends multiple final chunks after you stop speaking.
- Refined the dictation pill hover controls so the cancel and confirm buttons sit evenly inside the capsule.

## 1.2026.513-7 — 2026-05-13

- Fixed dictation completion so hold-to-talk streams audio in realtime and returns the final text promptly after you stop speaking.
- Added a realtime fallback that uses the latest live transcript if the provider misses the final response deadline.

## 1.2026.513-6 — 2026-05-13

- Added Import Audio so you can bring existing audio files into Zound and transcribe them like new recordings.
- Improved hold-to-talk dictation quality by sending captured dictation audio through the higher-quality backend transcription path, then cleaning up temporary and remote dictation recordings.
- Reduced the dictation island hover timer size so the compact pill controls stay readable without crowding.

## 1.2026.513-5 — 2026-05-13

- Fixed dictation island colors so light mode uses a light capsule with dark controls, and dark mode uses a dark capsule with light controls.

## 1.2026.513-4 — 2026-05-13

- Fixed the dictation island so its SwiftUI content is attached to the floating panel instead of creating an invisible blank panel.

## 1.2026.513-3 — 2026-05-13

- Fixed dictation shortcuts so Fn, modifier keys, and custom hotkeys reliably trigger after updates or permission resets.
- Dictation shortcuts now also work while Zound Settings is frontmost, without firing while recording a new custom hotkey.

## 1.2026.513-2 — 2026-05-13

- Fixed the dictation pill hover state so cancel and confirm controls no longer flicker under the pointer.
- Refined the dictation pill layout so the app icon and status icon sit at the outer edges while the hover timer stays centered.
- Redesigned Dictionary settings with a clearer editor, usage limit feedback, and a visible automatic-save state.

## 1.2026.513-1 — 2026-05-13

- Switched the beta transcription backend to Doubao by default for saved recordings.
- Aligned live dictation with the shared transcription provider so Doubao can power both recordings and hold-to-talk dictation unless a realtime override is configured.

## 1.2026.512-2 — 2026-05-12

- Fixed Activation Mode in Dictation settings so the selected mode stays saved instead of snapping back.
- Added Left Control + Space support through custom dictation hotkeys, with Delete clearing the current shortcut recording.
- Made the dictation island a compact pill with hover controls to cancel or confirm dictation and a running timer.
- Added a setting to keep the dictation pill fixed at the bottom center or show it near the active input box.
- Moved Dictionary into its own Settings tab right after General for faster access.

## 1.2026.512-1 — 2026-05-12

- Added customizable dictation hotkeys, including left-side modifier keys and custom key chords with live shortcut previews.
- Added a Clear action to the Customize Hotkey sheet so you can reset a custom shortcut without changing other dictation settings.
- Removed PostHog analytics tracking from Zound.
- Added the Zound Beta release channel for privately distributed beta builds and in-app beta updates.

## 1.2026.509-2 — 2026-05-09

- Fixed the update checker so Sparkle update windows come to the front when opened from the menu bar or Settings.
- Improved the release installer so new installs use a signed DMG with an Applications shortcut, preventing macOS download-location launches from blocking future auto-updates.

## 1.2026.509-1 — 2026-05-09

- Fixed microphone selection so recordings and hold-to-talk dictation use the input device you choose in Settings.

## 1.2026.430-2 — 2026-04-30

- Added an About section in Settings with the app icon, current version, update checks, and changelog access.
- Settings are now fully localized in Simplified Chinese, including Dictation keyboard shortcuts, activation modes, and Dictionary help text.
- Removed the floating Orb feature and its General Settings toggle, keeping Zound focused on the menu bar, Settings, and Voice Island surfaces.
- Improved Dictation recovery when realtime connections drop or finalization takes longer than expected, so finished text is preserved more reliably.

## 1.2026.430-1 — 2026-04-30

- Refined the Voice Island into a smaller, cleaner Liquid Glass-style panel that stays focused on dictation progress without extra transport text.
- Live dictation now shows in-progress recognized text while you keep holding Fn, instead of waiting until the session finishes.
- Final dictation text handles realtime sentinel markers and word boundaries more reliably, reducing stray tags and missing spaces in inserted text.
- Settings now use a clearer sidebar layout with grouped rows, making Dictation, Dictionary, and General controls easier to scan.
- Added an Enable Dictation switch so dictation can be turned off without changing shortcut or language preferences.
- Expanded Activation Keys with right-side modifier keys and common modifier combinations, alongside Fn.
- Added Hold, Toggle, Hold or Toggle, and Double Tap activation modes, with more reliable behavior when modifier chords change or dictation is disabled mid-session.

## 1.2026.428-2 — 2026-04-28

- Reduced Fn dictation startup latency by keeping a signed realtime gateway connection warm after launch and between dictation sessions.
- Switched live hold-to-talk dictation to Soniox realtime transcription while keeping recording transcription on Doubao.
- Added a Gateway Health check in Dictation Settings to verify the public realtime gateway and measure connection readiness.

## 1.2026.428-1 — 2026-04-28

- Lowered Zound's minimum macOS requirement to macOS Sequoia 15.0 or later.

## 1.2026.427-4 — 2026-04-27

- Restored low-latency hold-to-talk dictation by streaming microphone audio through Cabin's realtime gateway instead of uploading and polling a recording.
- Removed transport status text from the voice island during dictation, keeping the active UI focused on the waveform and the final inserted text.
- Shortened realtime finalization waits and kept Doubao credentials server-side while forwarding audio immediately.

## 1.2026.427-3 — 2026-04-27

- Fixed dictation's no-audio error so it correctly points to microphone capture instead of meeting/system audio.

## 1.2026.427-2 — 2026-04-27

- Switched hold-to-talk dictation to Cabin's async transcription pipeline for this MVP, avoiding the realtime gateway failure path while keeping voice typing available.
- Dictation status and errors are now readable in the voice island instead of being cropped out.

## 1.2026.427-1 — 2026-04-27

- New hold-to-talk dictation: hold Fn to speak and Zound types finalized text into the app you were already using.
- Added a lightweight voice island that appears near the text cursor, falls back to bottom center when needed, and shows a responsive waveform while you talk.
- Dictation now streams through Cabin's realtime gateway to Doubao realtime speech recognition, keeping the new writing flow separate from meeting recording and Live Captions.
- Added Keyboard Controls in Settings so you can choose Fn or another preset modifier shortcut for hold-to-talk recording.
- Added dictation setup guidance to onboarding, including microphone and accessibility permission checks without requiring System Audio permission.
- Dictation respects your transcription language hints and context dictionary for better names, products, jargon, and code-switching.
- Final audio and connection failures during dictation are now surfaced instead of silently clearing the session.

## 1.6.0 — 2026-04-27

- Recording details now have a built-in playback bar pinned to the bottom of the window, so you can listen to the audio while reading the transcript.
- The waveform is colored by speaker, giving you an at-a-glance map of who's talking when across the entire timeline.
- Click anywhere on the waveform to scrub, hover to preview the speaker and timestamp at that point, or tap any transcript turn to jump straight to it.
- The active speaker turn highlights as audio plays and gently scrolls into view, so you never lose your place.
- Transport controls include play/pause, ±10 second skip, and a 0.75×–2× speed menu, with Space, ←/→, and Shift+←/→ keyboard shortcuts.

## 1.5.0 — 2026-04-26

- Activation is now bound to your Mac — invite codes lock to the device that redeems them, so a leaked code can't be reused elsewhere.
- Live transcription and translation now connect through Zound's realtime gateway, improving connection reliability and securing the audio stream.
- Activation, transcription, and translation errors now appear in your selected app language with clearer descriptions when the server returns no detail.

## 1.4.2 — 2026-04-23

- Fixed microphone capture so the recorded audio level is properly normalized, preventing quiet or unbalanced recordings.

## 1.4.1 — 2026-04-23

- Live Captions now show in-progress words in a lighter style, so you can follow along before each phrase is finalized.
- Selecting a suggested speaker name in a draft now assigns it immediately, so you do not need to click Done after choosing from the list.
- Completed the permission setup screen's Simplified Chinese localization so the onboarding flow stays fully translated.
- Refreshed the starting, idle, and recording menu bar icons with updated artwork.

## 1.4.0 — 2026-04-22

- Fixed the Context Dictionary so every change saves immediately and is still there after switching tabs or closing Settings.
- Refreshed Settings with a more native macOS preferences layout that sizes to its content and lines up controls more cleanly.

## 1.3.0 — 2026-04-21

- Personal context dictionary now starts blank, so you can add your own names, products, jargon, and acronyms instead of inheriting shared defaults.
- Speaker suggestions now start empty and learn from the names you actually assign.
- Added a Transcription Languages picker in Settings → General so you can choose which languages the transcriber should expect.
- Added a new "What's New" window after updates, plus a "View What's New…" shortcut in Settings.
- Refreshed the app icon and replaced the menu bar status glyphs with custom Zound artwork.
- Settings now opens more reliably from the menu bar and uses a more native macOS Tahoe layout.

## 1.2.2 — 2026-04-20

- Export transcripts as .txt or .md.
- Recording summaries generate a title and a short excerpt automatically.

## 1.2.1 — 2026-04-19

- Renamed the app to Zound. Fixes and polish across recording, transcription, and permissions.
