# Changelog

## 1.2026.826-1 - 2026-08-26

- Fixed meeting recordings playing too fast and at a higher pitch when AirPods or other Bluetooth headsets changed audio profiles during capture.
- Meeting Recording, Dictation, and Microphone Check now detect stalled or interrupted audio capture, stop safely, and preserve recoverable meeting files instead of producing corrupted audio.

## 1.2026.819-1 - 2026-08-19

- Reduced background CPU use while Zound is idle, especially when a browser is frontmost.

## 1.2026.812-1 — 2026-08-12

- Fixed microphones connected through 44.1 kHz audio interfaces going silent immediately after capture started.

## 1.2026.811-1 — 2026-08-11

- New experimental AI Polish: rewrite finished dictations with per-app profiles — remove filler words, match the app's tone (casual for messaging, professional for email, verbatim for code editors), or write your own custom prompt. Off by default in Settings → Voice Dictation → AI Polish; falls back to your raw words if polishing takes longer than two seconds.
- Live Preview Typing now retracts corrections through a verified accessibility transaction where apps support it, replacing corrected words without visible backspacing.

## 1.2026.811 — 2026-08-11

- Fixed dictation occasionally pasting your previous clipboard contents instead of the transcribed text when the target app was slow to respond.
- New experimental Live Preview Typing: watch your words appear in the app you're dictating into as you speak, with the final text taking their place when you finish. Off by default — enable it under Settings → Voice Dictation.
- Back-to-back dictations no longer occasionally discard a healthy prepared connection, keeping the fast warm path reliable.

## 1.2026.808-2 — 2026-08-08

- Rapid back-to-back dictations now reliably prepare the next connection during the current dictation, restoring the fast warm path for short dictations.

## 1.2026.808-1 — 2026-08-08

- Rapid back-to-back dictations now prepare the next connection while the current dictation is active, so short dictations return results much faster instead of waiting on a fresh connection.

## 1.2026.807-5 — 2026-08-07

- Rapid back-to-back dictations no longer stop before recording begins when cleanup from the previous connection briefly fails.

## 1.2026.807-4 — 2026-08-07

- Fixed the microphone not picking up at the start of a dictation begun right after the previous one — recording now always starts immediately.

## 1.2026.807-3 — 2026-08-07

- Starting a dictation immediately after finishing one no longer gets interrupted — the app now rides the connection already being prepared instead of discarding it.

## 1.2026.807-2 — 2026-08-07

- Fixed kept-warm dictation connections being discarded on slower networks, which forced every dictation onto a slow fresh connection and could interrupt one started immediately after another.

## 1.2026.807-1 — 2026-08-07

- Dictation audio now uploads compressed (about a fifth of the data), keeping speech flowing smoothly on slow or congested networks.
- The app now adapts how long it waits for final text to your actual network conditions, so slow connections no longer cause dictations to give up on results that were about to arrive.

## 1.2026.806-3 — 2026-08-06

- Stopping a dictation mid-sentence no longer cuts off the last words — the full sentence is transcribed before results are returned.
- Dictation now checks that a kept-warm connection is actually healthy before using it, preventing interruptions from silently stalled connections.
- The app now tells the server exactly how long it will wait when you stop, so results reliably arrive before the app moves on — even on slow networks.

## 1.2026.806-2 — 2026-08-06

- Dictation now shows text streaming in live as you speak.
- If the transcription service stalls at the end of a dictation, you now receive the text that was already transcribed instead of an error.

## 1.2026.806-1 — 2026-08-06

- Fixed a rare race where a dictation whose connection recovery had already timed out could still capture audio into an abandoned session.
- Dictation recovery failures now surface immediately instead of occasionally stalling until the end of the dictation.

## 1.2026.805-2 — 2026-08-05

- Dictation now stays ready for up to three minutes between uses, so results arrive in about a second after stopping — even following a break.

## 1.2026.805-1 — 2026-08-05

- Dictation now recovers reliably after the app has been idle, and finishing against a slow connection no longer interrupts the session.
- Meeting transcription no longer fails when a brief service hiccup occurs while waiting for results.
- Added Send to Dex: deliver any completed recording's transcript to Dex from the library.
- Recordings now upload directly to secure storage, making large uploads faster and more reliable.

## 1.2026.804-2 — 2026-08-04

- Fixed Meeting Recording uploads that could stop before transcription started, with one safe automatic retry.

## 1.2026.804-1 — 2026-08-04

- Fixed repeated Dictation interruptions after the app had been idle, including the first attempt after a break.
- When enabled, completed Meeting Recording transcripts can now be delivered automatically to Dex, with safe retries and clear delivery status.

## 1.2026.803-4 — 2026-08-03

- Fixed Dictation after idle so ending a recording safely waits for an active connection instead of interrupting before transcription starts.

## 1.2026.803-3 - 2026-08-03

- Fixed Dictation sometimes failing on the first attempt after the app had been idle for several minutes.

## 1.2026.803-2 - 2026-08-03

- Fixed the first Dictation after idle so interrupted or expired connections no longer block the next attempt.
- Improved Dictation recovery when connection setup is interrupted before transcription starts.
- Made Sign Out stop active Dictation immediately while completing secure cleanup safely.

## 1.2026.803-1 - 2026-08-03

- Made Dictation finish faster and more reliably after the end key by finalizing realtime transcription directly.
- Improved rapid repeat Dictation and recovery while another result is finishing.
- Simplified Dictation Connection status and replaced persistent errors with dismissing diagnostics that can be copied or reported.
- Applied selected transcription languages as flexible hints while preserving multilingual detection.

## 1.2026.802-1 - 2026-08-02

- Fixed the first Dictation after a longer break so an expired background session is replaced before audio is sent.
- Improved Dictation recovery when connection setup and retry overlap.

## 1.2026.801-2 — 2026-08-01

- Made Dictation return results faster after the end key while preserving trailing speech from a held-key release.
- Fixed the first Dictation after a break so an expired background connection starts fresh instead of showing a false submission error.
- Simplified Dictation Connection diagnosis with a clear status and readable, copyable technical details.

## 1.2026.801-1 — 2026-08-01

- Improved Dictation reliability after idle and reduced delays on the first result.
- Made the Dictation key restart from an error without requiring the island to be closed manually.
- Kept Dictation failures contained to the island instead of also showing a large duplicate notification.

## 1.2026.731-3 — 2026-07-31

- Reissued the direct dictation beta after strengthening its signed install and update verification.

## 1.2026.731-2 — 2026-07-31

- Made dictation start and respond faster by connecting directly to the realtime speech service.
- Kept dictation reliable when the direct path is unavailable by falling back automatically without losing the recording.

## 1.2026.731-1 — 2026-07-31

- Fixed browser sign-in so Zound reliably returns to the app and leaves the welcome window after identity verification.
- Fixed dictation after an access session expires so renewal and legacy cleanup complete without a temporary service error.

## 1.2026.730-1 — 2026-07-30

- Added secure browser sign-in with automatic access renewal and clear Rebind handling when a session can no longer be renewed.
- Made Sign Out and Dex disconnect reliable across offline use and app restarts while preserving local recordings and transcripts.
- Improved recording and dictation recovery so interrupted work resumes safely without duplicate processing.
- Kept meeting audio at its natural speed and pitch when AirPods or another audio device changes sample rate during recording.

## 1.2026.605-1 — 2026-06-05

- Hardened meeting recording processing so sped-up or pitch-shifted mixdowns are rejected before they can be saved as successful captures.
- Preserved the original recording when processed audio timing is invalid, making recovery possible without uploading a broken file.

## 1.2026.604-3 — 2026-06-04

- Improved meeting prompts so Zound can use active microphone input as a secondary signal for recently detected meetings.
- Improved Google Meet detection for browser windows whose title starts with "Meet -".

## 1.2026.604-2 — 2026-06-04

- Added a meeting recording prompt that detects Zoom, FaceTime, Teams, and trusted Google Meet browser windows, so you can start recording from the island when a meeting appears active.
- Added a General setting to turn meeting recording prompts off.

## 1.2026.604-1 — 2026-06-04

- Fixed meeting recordings where system audio could be saved too short, sped up, and pitch-shifted.
- Added a finished-recording duration check so invalid captures are detected and preserved for recovery instead of being discarded.

## 1.2026.602-1 — 2026-06-02

- Fixed meeting recordings so quiet system-audio moments no longer trigger a System Audio Issue toast or discard the recording.
- Fixed recording uploads that could fail with a signed request body mismatch before transcription starts.
- Reduced unnecessary diagnostics from expected activation, microphone, and reauthorization states so real production issues are easier to spot.

## 1.2026.526-3 — 2026-05-26

- Fixed meeting recordings started with System Default microphone so Bluetooth headset inputs no longer cause pitched-up audio or missing microphone tracks.
- Added a Show in Finder button to Recording Drafts so saved audio is easier to locate.
- Improved live recording microphone warnings so capture problems appear as toasts without sending unnecessary error reports.

## 1.2026.526-2 — 2026-05-26

- Fixed system-audio recording warnings so they appear as toasts instead of taking over the menu bar.
- Fixed the Live Captions panel so it can be dragged to the top of the visible screen area.

## 1.2026.526-1 — 2026-05-26

- Reduced unnecessary error reports from expected microphone, activation, and system-audio states.
- Fixed recording summaries so empty transcripts no longer trigger a summary failure.
- Improved microphone cleanup to reduce the chance of Zound hanging while audio capture shuts down.

## 1.2026.525-4 — 2026-05-25

- Added a Recording Island setting so you can choose whether the recording status island stays on the left or right screen edge.
- Improved recording island dragging so it remembers vertical placement while staying pinned to the selected edge.
- Localized more toast notification text and refined notification icons for clearer status updates.

## 1.2026.525-3 — 2026-05-25

- Added a floating recording status island so recording, transcription, and system-audio states are easier to monitor while you work.
- Added in-app toast notifications for recording, import, transcription, captions, dictation, activation, permissions, export, and account events.
- Improved recording diagnostics and processed-audio validation so silent system audio, stalled capture, and invalid processed audio surface more clearly.

## 1.2026.525-2 — 2026-05-25

- Improved Soniox dictation accuracy by waiting for the final transcript on release and using the app language setting as a strict hint, reducing phantom word spacing.
- Reduced noisy dictation warning reports so recoverable microphone callback stalls no longer appear as high-priority errors.

## 1.2026.525-1 — 2026-05-25

- Fixed reactivation so a Mac that is asked to activate again can use a fresh invite without hitting a temporary activation service error.

## 1.2026.521-3 — 2026-05-21

- Added tag-style dictionary terms with paste parsing, so names, products, and domain phrases are easier to manage.
- Improved Doubao and Soniox dictionary handling so important terms are sent as provider-friendly hotwords/context.
- Localized the new dictionary controls and kept background context separate from the term list.

## 1.2026.521-2 — 2026-05-21

- Fixed a microphone selection regression that could stop dictation and recording from starting after an unavailable external microphone was preserved in settings.

## 1.2026.521-1 — 2026-05-21

- Fixed hold-to-talk dictation so the final words are preserved when the realtime provider closes or times out after sending transcript text.
- Improved selected-microphone recording so external microphones that are quiet or briefly silent still capture correctly instead of being treated as unavailable.
- Added bounded recovery for realtime dictation sessions so a broken connection cannot leave Zound stuck while stopping or reconnecting.
- Improved the realtime dictation gateway so beta builds handle upstream failures more reliably.

## 1.2026.514-4 — 2026-05-14

- Fixed English dictation so split words like "email" and "deal" stay together.
- Improved the microphone check so the default microphone name is easier to understand.

## 1.2026.514-3 — 2026-05-14

- Fixed recording startup so microphone checks no longer interrupt an active recording.
- Improved audio capture so recordings handle device and timing hiccups more reliably.
- Improved dictation spacing so words and phrases stay separated naturally.
- Added clearer error reports so we can spot and fix Zound problems faster.
- Fixed a menu issue that could make Zound feel stuck or repeat an action.

## 1.2026.514-2 — 2026-05-14

- Renamed Library to Transcripts and made it the main place for completed recordings and archived live-caption sessions.
- Recording details now open in the transcript draft view, with export in the toolbar and editable recording titles.
- Dictation History is now Dictations across the app, with matching menu-bar grouping and cleaner toolbar actions.
- Fixed English dictation spacing so natural phrases like "right now", "I'm just", and "trying to" stay separated.
- Live-vs-final transcript comparisons now highlight changed words, making review differences easier to scan.

## 1.2026.514-1 — 2026-05-14

- Added a unified Transcripts window that brings completed recordings and archived live-caption sessions into a single home, with filters, search, and quick navigation between linked items.
- Added a live-vs-final transcript comparison view: when a caption session is captured during a recording, you can now see the live captions and the final transcript side by side once processing finishes. Open Linked Recording jumps straight to the parent from a caption.
- Added automatic silence trimming for finished recordings. Leading and trailing silence is removed during save (with a small safety pad). Skipped when savings would be negligible or the file is fully silent. Toggle this from General settings (on by default); dictation audio is untouched.
- Added activate and processing sound cues for dictation and recording so you get audible feedback when a session starts and when transcription finishes. Toggle from General settings (on by default).
- Live caption sessions are now automatically archived when you close the translator panel, so captions are no longer dropped on the floor when the panel is dismissed.
- Closing the live-captions panel now fully tears down the translator session — no more lingering processing in the background.
- Fixed phantom spaces inside English dictation transcripts so subword splits no longer land as gaps inside a single word.
- Refined the Dictations toolbar layout for clearer replay, copy, delete, and re-transcribe actions.

## 1.2026.513-12 — 2026-05-13

- Fixed phantom spaces inside Chinese and Japanese dictation transcripts so realtime providers no longer split words mid-sentence (for example, "星 期三" now stays as "星期三"). Korean, Latin, and digit boundaries are preserved.
- Dictation history, the transcript draft caption, and the Recent Recordings menu now show human-readable relative dates like "just now", "5m ago", or "2d ago". Hover any entry to see the full absolute timestamp.
- Empty dictations from very brief hotkey taps or silent moments are now silently dismissed for the first two in a row — no error pill, no history row. A third consecutive empty still surfaces the error so a genuinely broken setup announces itself.
- Improved the dictation island appearance on macOS 26 glass so its content tones follow the visible backdrop rather than only the system appearance, staying readable on both Light and Dark wallpapers.
- Localized the menu bar "Dictations…" item in Simplified Chinese.

## 1.2026.513-11 — 2026-05-13

- Fixed Soniox realtime dictation so the warm connection is discarded before it can age past the provider's idle timeout, preventing the constant "Audio data decode timeout" failures after switching providers.
- Fixed the dictation island so it matches the system appearance on macOS 26 — no more dark capsule with light text in Light Mode.
- The error state now shows the actual failure message on hover, so you can see what went wrong without checking history.
- Failed dictations now save their captured audio to Dictations, so you can replay or re-transcribe them instead of losing the recording.
- Dictations is now fully localized in Simplified Chinese.

## 1.2026.513-10 — 2026-05-13

- Refined the Dictations toolbar with clearer actions for replay, copy, delete, and re-transcribe.
- Improved the dictation island error state with a clearer message and easier recovery.
- Made re-transcribing past dictations more reliable.
- Polished Simplified Chinese copy across dictation, history, and settings for consistent terminology.

## 1.2026.513-9 — 2026-05-13

- Added Dictations to review, replay, copy, delete, and re-transcribe past dictations, including failed or timed-out sessions.
- Added Dictations settings for saving audio and automatic cleanup.
- Improved long dictations so trailing speech is less likely to be cut off while finishing.
- Refined the dictation island with a clearer error state, a cleaner live waveform, and a smaller animated processing state.
- The Context Dictionary editor now grows as you add longer content.

## 1.2026.513-8 — 2026-05-13

- Fixed realtime dictation finalization so the last words stay intact when the provider sends multiple final chunks after you stop speaking.
- Refined the dictation pill hover controls so the cancel and confirm buttons sit evenly inside the capsule.

## 1.2026.513-7 — 2026-05-13

- Fixed dictation completion so hold-to-talk streams audio in realtime and returns the final text promptly after you stop speaking.
- Added a realtime fallback that uses the latest live transcript if the provider misses the final response deadline.

## 1.2026.513-6 — 2026-05-13

- Added Import Audio so you can bring existing audio files into Zound and transcribe them like new recordings.
- Improved hold-to-talk dictation quality by sending captured dictation audio through the higher-quality backend transcription path, then cleaning up temporary and remote dictation recordings.
- Reduced the dictation island hover timer size so the compact pill controls stay readable without crowding.

## 1.2026.513-5 — 2026-05-13

- Fixed dictation island colors so light mode uses a light capsule with dark controls, and dark mode uses a dark capsule with light controls.

## 1.2026.513-4 — 2026-05-13

- Fixed the dictation island so its SwiftUI content is attached to the floating panel instead of creating an invisible blank panel.

## 1.2026.513-3 — 2026-05-13

- Fixed dictation shortcuts so Fn, modifier keys, and custom hotkeys reliably trigger after updates or permission resets.
- Dictation shortcuts now also work while Zound Settings is frontmost, without firing while recording a new custom hotkey.

## 1.2026.513-2 — 2026-05-13

- Fixed the dictation pill hover state so cancel and confirm controls no longer flicker under the pointer.
- Refined the dictation pill layout so the app icon and status icon sit at the outer edges while the hover timer stays centered.
- Redesigned Dictionary settings with a clearer editor, usage limit feedback, and a visible automatic-save state.

## 1.2026.513-1 — 2026-05-13

- Switched the beta transcription backend to Doubao by default for saved recordings.
- Aligned live dictation with the shared transcription provider so Doubao can power both recordings and hold-to-talk dictation unless a realtime override is configured.

## 1.2026.512-2 — 2026-05-12

- Fixed Activation Mode in Dictation settings so the selected mode stays saved instead of snapping back.
- Added Left Control + Space support through custom dictation hotkeys, with Delete clearing the current shortcut recording.
- Made the dictation island a compact pill with hover controls to cancel or confirm dictation and a running timer.
- Added a setting to keep the dictation pill fixed at the bottom center or show it near the active input box.
- Moved Dictionary into its own Settings tab right after General for faster access.

## 1.2026.512-1 — 2026-05-12

- Added customizable dictation hotkeys, including left-side modifier keys and custom key chords with live shortcut previews.
- Added a Clear action to the Customize Hotkey sheet so you can reset a custom shortcut without changing other dictation settings.
- Removed PostHog analytics tracking from Zound.
- Added the Zound Beta release channel for privately distributed beta builds and in-app beta updates.

## 1.2026.509-2 — 2026-05-09

- Fixed the update checker so Sparkle update windows come to the front when opened from the menu bar or Settings.
- Improved the release installer so new installs use a signed DMG with an Applications shortcut, preventing macOS download-location launches from blocking future auto-updates.

## 1.2026.509-1 — 2026-05-09

- Fixed microphone selection so recordings and hold-to-talk dictation use the input device you choose in Settings.

## 1.2026.430-2 — 2026-04-30

- Added an About section in Settings with the app icon, current version, update checks, and changelog access.
- Settings are now fully localized in Simplified Chinese, including Dictation keyboard shortcuts, activation modes, and Dictionary help text.
- Removed the floating Orb feature and its General Settings toggle, keeping Zound focused on the menu bar, Settings, and Voice Island surfaces.
- Improved Dictation recovery when realtime connections drop or finalization takes longer than expected, so finished text is preserved more reliably.

## 1.2026.430-1 — 2026-04-30

- Refined the Voice Island into a smaller, cleaner Liquid Glass-style panel that stays focused on dictation progress without extra transport text.
- Live dictation now shows in-progress recognized text while you keep holding Fn, instead of waiting until the session finishes.
- Final dictation text handles realtime sentinel markers and word boundaries more reliably, reducing stray tags and missing spaces in inserted text.
- Settings now use a clearer sidebar layout with grouped rows, making Dictation, Dictionary, and General controls easier to scan.
- Added an Enable Dictation switch so dictation can be turned off without changing shortcut or language preferences.
- Expanded Activation Keys with right-side modifier keys and common modifier combinations, alongside Fn.
- Added Hold, Toggle, Hold or Toggle, and Double Tap activation modes, with more reliable behavior when modifier chords change or dictation is disabled mid-session.

## 1.2026.428-2 — 2026-04-28

- Reduced Fn dictation startup latency by keeping a signed realtime gateway connection warm after launch and between dictation sessions.
- Switched live hold-to-talk dictation to Soniox realtime transcription while keeping recording transcription on Doubao.
- Added a Gateway Health check in Dictation Settings to verify the public realtime gateway and measure connection readiness.

## 1.2026.428-1 — 2026-04-28

- Lowered Zound's minimum macOS requirement to macOS Sequoia 15.0 or later.

## 1.2026.427-4 — 2026-04-27

- Restored low-latency hold-to-talk dictation by streaming microphone audio through Cabin's realtime gateway instead of uploading and polling a recording.
- Removed transport status text from the voice island during dictation, keeping the active UI focused on the waveform and the final inserted text.
- Shortened realtime finalization waits and kept Doubao credentials server-side while forwarding audio immediately.

## 1.2026.427-3 — 2026-04-27

- Fixed dictation's no-audio error so it correctly points to microphone capture instead of meeting/system audio.

## 1.2026.427-2 — 2026-04-27

- Switched hold-to-talk dictation to Cabin's async transcription pipeline for this MVP, avoiding the realtime gateway failure path while keeping voice typing available.
- Dictation status and errors are now readable in the voice island instead of being cropped out.

## 1.2026.427-1 — 2026-04-27

- New hold-to-talk dictation: hold Fn to speak and Zound types finalized text into the app you were already using.
- Added a lightweight voice island that appears near the text cursor, falls back to bottom center when needed, and shows a responsive waveform while you talk.
- Dictation now streams through Cabin's realtime gateway to Doubao realtime speech recognition, keeping the new writing flow separate from meeting recording and Live Captions.
- Added Keyboard Controls in Settings so you can choose Fn or another preset modifier shortcut for hold-to-talk recording.
- Added dictation setup guidance to onboarding, including microphone and accessibility permission checks without requiring System Audio permission.
- Dictation respects your transcription language hints and context dictionary for better names, products, jargon, and code-switching.
- Final audio and connection failures during dictation are now surfaced instead of silently clearing the session.

## 1.6.0 — 2026-04-27

- Recording details now have a built-in playback bar pinned to the bottom of the window, so you can listen to the audio while reading the transcript.
- The waveform is colored by speaker, giving you an at-a-glance map of who's talking when across the entire timeline.
- Click anywhere on the waveform to scrub, hover to preview the speaker and timestamp at that point, or tap any transcript turn to jump straight to it.
- The active speaker turn highlights as audio plays and gently scrolls into view, so you never lose your place.
- Transport controls include play/pause, ±10 second skip, and a 0.75×–2× speed menu, with Space, ←/→, and Shift+←/→ keyboard shortcuts.

## 1.5.0 — 2026-04-26

- Activation is now bound to your Mac — invite codes lock to the device that redeems them, so a leaked code can't be reused elsewhere.
- Live transcription and translation now connect through Zound's realtime gateway, improving connection reliability and securing the audio stream.
- Activation, transcription, and translation errors now appear in your selected app language with clearer descriptions when the server returns no detail.

## 1.4.2 — 2026-04-23

- Fixed microphone capture so the recorded audio level is properly normalized, preventing quiet or unbalanced recordings.

## 1.4.1 — 2026-04-23

- Live Captions now show in-progress words in a lighter style, so you can follow along before each phrase is finalized.
- Selecting a suggested speaker name in a draft now assigns it immediately, so you do not need to click Done after choosing from the list.
- Completed the permission setup screen's Simplified Chinese localization so the onboarding flow stays fully translated.
- Refreshed the starting, idle, and recording menu bar icons with updated artwork.

## 1.4.0 — 2026-04-22

- Fixed the Context Dictionary so every change saves immediately and is still there after switching tabs or closing Settings.
- Refreshed Settings with a more native macOS preferences layout that sizes to its content and lines up controls more cleanly.

## 1.3.0 — 2026-04-21

- Personal context dictionary now starts blank, so you can add your own names, products, jargon, and acronyms instead of inheriting shared defaults.
- Speaker suggestions now start empty and learn from the names you actually assign.
- Added a Transcription Languages picker in Settings → General so you can choose which languages the transcriber should expect.
- Added a new "What's New" window after updates, plus a "View What's New…" shortcut in Settings.
- Refreshed the app icon and replaced the menu bar status glyphs with custom Zound artwork.
- Settings now opens more reliably from the menu bar and uses a more native macOS Tahoe layout.

## 1.2.2 — 2026-04-20

- Export transcripts as .txt or .md.
- Recording summaries generate a title and a short excerpt automatically.

## 1.2.1 — 2026-04-19

- Renamed the app to Zound. Fixes and polish across recording, transcription, and permissions.
